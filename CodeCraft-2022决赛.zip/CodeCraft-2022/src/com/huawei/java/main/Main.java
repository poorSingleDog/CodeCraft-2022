package com.huawei.java.main;
public class Main {

	public static void main(String[] args) {
		Start test = new Start();
		test.run("/data", "/output/solution.txt");

	}
}
