package com.huawei.java.main;

import java.util.*;

public class Server {
    public String id;           //id
    public int num;             //编号
    public int band_width;      //最大带宽
    public int clientNum=0;       //客户数
    public List<Client> clientList;     //客户列表
    public double priority=0;        //优先级
    public int sacrificeNum;        //牺牲次数
    public int sacriMax=0;
    public int burden=0;            //相连客户需求和
    public int upper_limit=0;         //每刻的上限
    public int vrest;               //以v为上限，可用余量
    public int used=0;              //填未满足的流的时候使用的次数（目的使所有边缘用量大概平均）
    public int allsend=0;            //95%部分总用量
    public int maxuse=0;            //95%部分用量最大值
    public Boolean ischeap=false;
    public static int base_cost;        //V
    public static double center_cost;   //A
    public Set<Integer> sacri_times;    //牺牲时刻
    public Map<Integer,Integer> time_rest;
    public Map<Integer,Integer> sendout;    //95%个时刻的分配量
    public List<Map.Entry<Integer,Integer>> SendOut;
    public Map<Integer,List<Stream>> receivedStream;    //《时刻-接收的流们》
    public Map<Integer,String> names;          //<时刻-已收到的流id>
    public Map<Integer,Set<String>> t_liu;
    public Map<String,Integer> liu_max;
    public Boolean isDead=false;      //是否不与任何客户相连

    public Server(){
        this.clientList=new ArrayList<>();
        this.sacri_times=new HashSet<>();
        this.time_rest=new HashMap<>();
        this.sendout=new HashMap<>();
        this.receivedStream=new HashMap<>();
        this.names=new HashMap<>();
        this.t_liu=new HashMap<>();
    }
    public static Server[] init(String path){      //path="data",初始化所有边缘节点的最大带宽、id、序号、剩余带宽、牺牲次数，没有初始化关于边缘节点的部分

        String[][] info=Readfile.readcsv(path+"/site_bandwidth.csv");
        Server[] servers=new Server[info.length-1];
        for(int i=1;i<info.length;i++){
            servers[i-1]=new Server();
            servers[i-1].num=i-1;
            servers[i-1].id=info[i][0];
            servers[i-1].band_width=Integer.valueOf(info[i][1]);
            servers[i-1].sacrificeNum=0;
        }
        double[] in=Readfile.readini(path+"/config.ini");
        base_cost= (int) in[1];
        center_cost=in[2];
        return servers;
    }
    public static int[][] getGragh(Server[] servers,Client[] clients,String path){
        String[][] info=Readfile.readcsv(path+"/qos.csv");
        int config=(int)Readfile.readini(path+"/config.ini")[0];     //400以内相通
        String[] c=new String[info[0].length-1];
        String[] s=new String[info.length-1];
        Map<String,Integer> cc=new HashMap<>();
        Map<String,Integer> ss=new HashMap<>();
        for(int i=1;i<info[0].length;i++){
            c[i-1]=info[0][i];
        }
        for(int i=1;i<info.length;i++){
            s[i-1]=info[i][0];
        }
        for(Client client:clients){
            cc.put(client.id,client.num);
        }
        for(Server server:servers){
            ss.put(server.id,server.num);
        }
        int[][] old=new int[info.length-1][info[0].length-1];
        for(int i=1;i<info.length;i++){
            for(int j=1;j<info[0].length;j++){
                if(Integer.valueOf(info[i][j])<config){
                    old[i-1][j-1]=1;
                }else {
                    old[i-1][j-1]=0;
                }
            }
        }
        int[][] fresh=new int[info.length-1][info[0].length-1];
        for(int i=0;i<old.length;i++){
            for(int j=0;j<old[0].length;j++){
                if(old[i][j]==1){
                    fresh[ss.get(s[i])][cc.get(c[j])]=1;
                }
            }
        }
        return fresh;
    }

    public static Server[] getClientInfo(Server[] servers,Client[] clients,String path){     //给本来一波servers加上客户信息,path="data"
        int[][] gragh=getGragh(servers,clients,path);
        for(int i=0;i<gragh.length;i++){
            for(int j=0;j<gragh[0].length;j++){
                if(gragh[i][j]==1) {
                    servers[i].clientNum++;
                    servers[i].clientList.add(clients[j]);
                }
            }
        }
        for(int i=0;i<servers.length;i++){
            if(servers[i].clientNum==0)
                servers[i].isDead=true;
        }

        return servers;
    }
    public static Server[] abandon(Server[] servers,int lines){       //若该边缘的线数很少且不是某一客户的唯一依赖，去除该边缘(容量太小是否也应该去除)
        List<Integer> abandonNum=new ArrayList<>();
        l:for(Server s:servers){
            if(s.clientNum<=lines){
                for(Client c:s.clientList){
                    if(c.serverNum<=3){         //如果该客户很依赖该边缘，则选择不删除该边缘
                        continue l;
                    }
                }
                abandonNum.add(s.num);
            }
        }
        Server[] res=new Server[servers.length-abandonNum.size()];
        int i=0;
        for(Server s:servers){
            if(abandonNum.contains(s.num)){
                continue;
            }else {
                res[i++]=s;
            }
        }
        return res;
    }

    public static void main(String[] args) {
        Server[] servers=init("data");
        Client[] clients=Client.init("data");
        int[][] gragh=getGragh(servers,clients,"data");
        for(int i=0;i<gragh.length;i++){
            for(int j=0;j<gragh[0].length;j++){
                System.out.print(gragh[i][j]+"  ");
            }
            System.out.println();
        }
    }
}