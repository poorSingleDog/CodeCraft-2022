package com.huawei.java.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Readfile {
    public static String[][] readcsv(String path){
        String line;
        String cvsSplitBy = ",";

        try(LineNumberReader lineNumberReader=new LineNumberReader(new FileReader(path))){
            lineNumberReader.skip(Long.MAX_VALUE);
            int n=lineNumberReader.getLineNumber();
            String[][] res=new String[n][];            //不知道几列
            try (BufferedReader br = new BufferedReader(new FileReader(path))) {
                int i=0;
                while ((line = br.readLine()) != null) {
                    // use comma as separator
                    String[] item = line.split(cvsSplitBy);
                    res[i]=item;
                    i++;

                }
                return res;

            } catch (IOException e) {
                e.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public static double[] readini(String path) {
        double[] res=new double[3];
        String line;
        String temp_qos="";
        String base_cost="";
        String center_cost="";
        StringBuffer qos_constraint=new StringBuffer();
        StringBuffer v=new StringBuffer();
        StringBuffer A=new StringBuffer();
        Boolean k=false;
        Boolean f=false;
        Boolean c=false;
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            int i = 0;
            while ((line = br.readLine()) != null) {
                // use comma as separator
                if (i == 1) {
                    temp_qos = line;
                }
                if(i==2){
                    base_cost=line;
                }
                if(i==3){
                    center_cost=line;
                    break;
                }

                i++;
            }
            for(int j=0;j<temp_qos.length();j++){

                if(k==true){
                    qos_constraint.append(temp_qos.charAt(j));
                }
                if(temp_qos.charAt(j)=='=')
                    k=true;

            }
            for(int j=0;j<base_cost.length();j++){

                if(f==true){
                    v.append(base_cost.charAt(j));
                }
                if(base_cost.charAt(j)=='=')
                    f=true;

            }
            for(int j=0;j<center_cost.length();j++){

                if(c==true){
                    A.append(center_cost.charAt(j));
                }
                if(center_cost.charAt(j)=='=')
                    c=true;

            }
            res[0]=Double.valueOf(String.valueOf(qos_constraint));
            res[1]=Double.valueOf(String.valueOf(v));
            res[2]=Double.valueOf(String.valueOf(A));
            return res;
        }catch (Exception e){
            e.printStackTrace();
        }
        return res;
    }

    public static void main(String[] args) {
        double[] res=readini("data/config.ini");
        System.out.println((int)res[0]);
        System.out.println((int)res[1]);
        System.out.println(res[2]);
    }
}