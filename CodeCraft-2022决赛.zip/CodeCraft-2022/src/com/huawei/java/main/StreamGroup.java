package com.huawei.java.main;

import java.util.ArrayList;
import java.util.List;

public class StreamGroup {
    public List<Stream> streams;
    public int needSum;
    public String id;
    public StreamGroup(){
        streams=new ArrayList<>();

    }
    public boolean getInfo(){
        int res=0;
        String str=streams.get(0).id;
        for(Stream stream:streams){
            if(!str.equals(stream.id)){
                return false;
            }
            res+=stream.need;
        }
        needSum=res;
        return true;
    }
}
