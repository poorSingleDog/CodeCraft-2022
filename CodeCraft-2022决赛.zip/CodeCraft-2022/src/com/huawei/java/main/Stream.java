package com.huawei.java.main;

public class Stream {
    public String id;
    public int need;
    public Client parent;
    public Stream(Client parent,String id,int need){
        this.id=id;
        this.need=need;
        this.parent=parent;
    }
}