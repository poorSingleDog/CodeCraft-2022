package com.huawei.java.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Client {
    public String id;                           //id
    public int num;                             //编号
    public Map<Integer,Map<String,Integer>> stream_demand;          //时刻--（流id--流需求）
    public int serverNum=0;                       //连到的边缘的数量
    public int priority=Integer.MIN_VALUE;                        //优先级
    public List<Server> serverList;             //边缘节点列表
    public static int times;                    //时刻数
    public Client(){
        this.serverList=new ArrayList<>();
        this.stream_demand=new HashMap<>();
    }
    public static Client[] init(String path) {   //path="data",没有初始化关于边缘节点的部分
        String[][] info=Readfile.readcsv(path+"/demand.csv");
        Client[] clients=new Client[info[0].length-2];
        for(int i=0;i<clients.length;i++){
            clients[i]=new Client();
        }
        for(int i=2;i<info[0].length;i++){
            clients[i-2].num=i-2;
            clients[i-2].id=info[0][i];
        }
        int t=1;
        String currentTime=info[1][0];
        for(int i=1;i<info.length;i++){
            if(!info[i][0].equals(currentTime)) {      //不属于同一时刻
                t++;
                currentTime=info[i][0];
            }
        }
        times=t;
        for(int i=0;i<clients.length;i++){
            Map[] id_remain=new Map[times];         //每个客户的每个时刻都有关于流的map
            for(int j=0;j<times;j++)
                id_remain[j]=new HashMap<String,Integer>();
            currentTime=info[1][0];
            int time=0;
            for(int j=1;j<info.length;j++){         //一行一行往下
                if(info[j][0].equals(currentTime)){
                    id_remain[time].put(info[j][1],Integer.valueOf(info[j][i+2]));
                }else if(!info[j][0].equals(currentTime)){
                    currentTime=info[j][0];
                    id_remain[++time].put(info[j][1],Integer.valueOf(info[j][i+2]));
                }
            }
            for(int j=0;j<times;j++){
                clients[i].stream_demand.put(j,id_remain[j]);
            }
        }
        return clients;

    }
    public static Client[] getServerInfo(Server[] servers,Client[] clients,String path) {
        int[][] gragh=Server.getGragh(servers, clients, path);
        for(int i=0;i<gragh.length;i++){
            for(int j=0;j<gragh[0].length;j++){
                if(gragh[i][j]==1){
                    clients[j].serverNum++;
                    clients[j].serverList.add(servers[i]);
                }
            }
        }
        return clients;
    }

    public static void main(String[] args) {
        Client[] c=init("data");
        System.out.println("times:"+Client.times);
        System.out.println("时间数："+c[0].stream_demand.size());
        System.out.println("0时刻流的种数："+c[0].stream_demand.get(0).size());

        for(int i=0;i<c.length;i++){
            System.out.print(c[i].id+":");
            for(Map.Entry<String,Integer> entry:c[i].stream_demand.get(0).entrySet()){      //每行是一个客户在0时刻的所有流需求
                System.out.print(entry.getKey()+"--"+entry.getValue()+"\t");
            }
            System.out.println();
        }

    }
}