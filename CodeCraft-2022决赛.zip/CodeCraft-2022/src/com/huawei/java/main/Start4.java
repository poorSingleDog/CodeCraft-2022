package com.huawei.java.main;

import java.io.IOException;
import java.util.*;

public class Start4 {           //不加上限，乱分时刻根据旧公式乱分；一束束分时刻根据新公式分
    public String deleteStream(String originStr,String streamId){
        String res="";
        String[] streams=originStr.split(",");      //streams[0]是""
        for(int i=1;i<streams.length;i++){
            if(streams[i].equals(streamId)){
                continue;
            }
            res+=","+streams[i];
        }
        return res;
    }

    public void run(String path,String out){
        Server[] servers1 = Server.init(path);
        Client[] clients1 = Client.init(path);
        Server[] servers = Server.getClientInfo(servers1, clients1, path);
        Client[] clients = Client.getServerInfo(servers1, clients1, path);


        int sacrificeMax = (int) (Client.times * 0.05);         //同一个边缘节点最大白嫖次数
        int[][] gragh = Server.getGragh(servers1, clients1, path);                    //存放每个客户的原始边缘节点列表
        int[] static_servernum = new int[clients.length];         //存放每个客户的原始线数
        for (int i = 0; i < clients.length; i++) {
            static_servernum[i] = clients[i].serverNum;
        }
        int[] static_clientnum = new int[servers.length];
        for (int i = 0; i < servers.length; i++) {
            static_clientnum[i] = servers[i].clientNum;
        }
        for (int i = 0; i < servers.length; i++) {
            for (int j = 0; j < Client.times; j++) {
                servers[i].time_rest.put(j, servers[i].band_width);  //初始化每个边缘的<时刻-余量>表
            }
        }
        SingleStrategy[][] output = new SingleStrategy[Client.times][clients.length];     //[时刻数][客户数] map<边缘id，流id>
        for (int i = 0; i < output.length; i++) {
            for (int j = 0; j < output[0].length; j++) {
                output[i][j] = new SingleStrategy();
            }
        }
        for(int i=0;i<Client.times;i++){
            for(Server s:servers){
                s.receivedStream.put(i,new ArrayList<>());      //给每个边缘在每个时刻都初始化空的Stream容器
                s.t_liu.put(i,new HashSet<>());
            }
        }
        List<Integer> center_times=new ArrayList<>();       //乱分的5个时刻
        //-------------------------------------------开始5%部分----------------------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {         //test:边缘节点按照容量降序排序
            @Override
            public int compare(Server o1, Server o2) {
                return o2.band_width - o1.band_width;
            }
        });
        for(int i=0;i<servers.length;i++){      //对每一列
            if(servers[i].isDead){
                continue;
            }
            Map<Integer,Integer> t_b=new HashMap<>();
            for(int j=0;j<Client.times;j++){
                int sum=0;
                for(Client c:servers[i].clientList){
                    for(int singleStream:c.stream_demand.get(j).values()){
                        sum+=singleStream;
                    }
                }
                t_b.put(j,sum);
            }
            List<Map.Entry<Integer, Integer>> T_B = new ArrayList<>(t_b.entrySet());
            Collections.sort(T_B, new Comparator<Map.Entry<Integer, Integer>>() {       //将一列根据相连客户需求和降序排序
                @Override
                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                    return o2.getValue() - o1.getValue();
                }
            });
            for(int j=0;j<sacrificeMax;j++){            //对这一列的前5%行进行分配,时刻=T_B.get(j).getKey()
                servers[i].sacri_times.add(T_B.get(j).getKey());
                servers[i].sacrificeNum++;
                Collections.sort(servers[i].clientList, new Comparator<Client>() {      //对该边缘下面的客户进行线数升序排序
                    @Override
                    public int compare(Client o1, Client o2) {
                        return o1.serverNum - o2.serverNum;
                    }
                });
                List<Stream> liu=new ArrayList<>();         //存储i时刻中所有未满足的流
                for(Client c:servers[i].clientList){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(T_B.get(j).getKey()).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                //找server[i]连通的流中最大的流
                for(Stream stream:liu){
                    if(servers[i].time_rest.get(T_B.get(j).getKey())-(int)(servers[i].band_width*0.05+1)>=stream.need){
                        servers[i].time_rest.put(T_B.get(j).getKey(),servers[i].time_rest.get(T_B.get(j).getKey())-stream.need);
                        stream.parent.stream_demand.get(T_B.get(j).getKey()).put(stream.id,0);
                        servers[i].receivedStream.get(T_B.get(j).getKey()).add(stream);     //找准时刻，添加流
                        servers[i].t_liu.get(i).add(stream.id);
                        output[T_B.get(j).getKey()][stream.parent.num].item.put(servers[i].id,output[T_B.get(j).getKey()][stream.parent.num].item.getOrDefault(servers[i].id,"")+","+stream.id);
                    }else if(servers[i].time_rest.get(T_B.get(j).getKey())-(int)(servers[i].band_width*0.05+1)<stream.need){
                        continue;
                    }
                }
            }
        }

        Map<Integer,Integer> t_sumNeed=new HashMap<>();
        for(int i=0;i<Client.times;i++){
            int sum=0;
            for (Client client : clients) {
                for (int need : client.stream_demand.get(i).values()) {
                    sum += need;
                }
            }
            t_sumNeed.put(i,sum);
        }
        List<Map.Entry<Integer,Integer>> T_SUM=new ArrayList<>(t_sumNeed.entrySet());
        Collections.sort(T_SUM, new Comparator<Map.Entry<Integer, Integer>>() {
            @Override
            public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                return o2.getValue()-o1.getValue();
            }
        });
        for(int i=0;i<(int)(Client.times*0.05)-1;i++){      //减一记得改成加一
            center_times.add(T_SUM.get(i).getKey());
        }
        //--------------------------------------------------开始95%部分-----------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {         //将servers排回原来顺序
            @Override
            public int compare(Server o1, Server o2) {
                return o1.num - o2.num;
            }
        });
//        for(int i=0;i<Client.times;i++){        //-------------填掉每个边缘节点的V
//            if(i!=0){
//                for(Server s:servers){      //更新该时刻的余量，减去缓存
//                    s.time_rest.put(i,s.time_rest.get(i)-(int)(0.05*(s.band_width-s.time_rest.get(i-1))));
//                }
//            }
//            for(Server s:servers)
//                s.vrest=Math.min(Server.base_cost,s.band_width);       //每时刻开始，边缘节点的上限设为v和带宽的较小值
//            List<Server> aliveS=new ArrayList<>();
//            for(int j=0;j<servers.length;j++){
//                if(servers[j].sacri_times.contains(i)||servers[j].isDead){
//                    continue;
//                }else {
//                    aliveS.add(servers[j]);
//                }
//            }
//            Collections.sort(aliveS, new Comparator<Server>() {     //给活边缘节点按线数升序排序 (或者先比线数后比容量？)******
//                @Override
//                public int compare(Server o1, Server o2) {
//                    return o1.clientNum-o2.clientNum;
//                }
//            });
//            for(Server s:aliveS){
//                List<Stream> liu=new ArrayList<>();
//                for(Client c:s.clientList){
//                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
//                        if(entry.getValue()!=0){
//                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
//                        }
//                    }
//                }
//                Collections.sort(liu, new Comparator<Stream>() {
//                    @Override
//                    public int compare(Stream o1, Stream o2) {
//                        return o2.need-o1.need;
//                    }
//                });
//                for(Stream stream:liu){
//                    if(s.vrest<stream.need){
//                        continue;
//                    }else if(s.vrest>=stream.need){
//                        s.vrest-=stream.need;
//                        s.time_rest.put(i,s.time_rest.get(i)-stream.need);
//                        stream.parent.stream_demand.get(i).put(stream.id,0);
//                        s.receivedStream.get(i).add(stream);        //找准时刻，添加流
//                        output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
//                    }
//                }
//            }
//
//            //开始检查客户下的流是否都已经为0,把未得到满足的流id存起来，统一处理
//
//        }

        //----------------------------------------------------填完V之后-------------------------------------------------------

        //--------------------------------遍历时刻，判断是否要采取乱分
        for(int i=0;i<Client.times;i++) {
            if (center_times.contains(i)) {
                List<Stream> liu = new ArrayList<>();         //存储i时刻中所有未满足的流
                for (Client c : clients) {
                    for (Map.Entry<String, Integer> entry : c.stream_demand.get(i).entrySet()) {
                        if (entry.getValue() != 0) {
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need - o1.need;
                    }
                });
                p:
                for (Stream stream : liu) {         //上限以内，用什么规定边缘节点优先级?(边缘节点线数少的优先)

                        for (Server s : servers) {      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                            s.priority = (2.0 * (s.band_width - s.time_rest.get(i) - Server.base_cost) + stream.need) / s.band_width;
                        }
                        Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                            @Override
                            public int compare(Server o1, Server o2) {
                                if (o1.priority < o2.priority)
                                    return -1;
                                else if (o1.priority > o2.priority)
                                    return 1;
                                else
                                    return 0;
                            }
                        });
                        for (Server s : stream.parent.serverList) {
                            if (s.time_rest.get(i) < stream.need)
                                continue;
                            else if (s.time_rest.get(i) >= stream.need) {
                                s.time_rest.put(i, s.time_rest.get(i) - stream.need);
                                stream.parent.stream_demand.get(i).put(stream.id, 0);
                                s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                                output[i][stream.parent.num].item.put(s.id, output[i][stream.parent.num].item.getOrDefault(s.id, "") + "," + stream.id);
                                continue p;
                            }
                        }
                }

            }else {         //用新优先级公式
                List<Stream> liu = new ArrayList<>();         //存储i时刻中所有未满足的流
                for (Client c : clients) {
                    for (Map.Entry<String, Integer> entry : c.stream_demand.get(i).entrySet()) {
                        if (entry.getValue() != 0) {
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need - o1.need;
                    }
                });
                p:
                for (Stream stream : liu) {         //上限以内，用什么规定边缘节点优先级?(边缘节点线数少的优先)

                    for (Server s : servers) {      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                        s.priority=(2.0*(s.band_width-s.time_rest.get(i)-Server.base_cost)+stream.need)/s.band_width+Server.center_cost* (s.t_liu.get(i).contains(stream.id)?0: 1);
                    }
                    Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                        @Override
                        public int compare(Server o1, Server o2) {
                            if (o1.priority < o2.priority)
                                return -1;
                            else if (o1.priority > o2.priority)
                                return 1;
                            else
                                return 0;
                        }
                    });
                    for (Server s : stream.parent.serverList) {
                        if (s.time_rest.get(i) < stream.need)
                            continue;
                        else if (s.time_rest.get(i) >= stream.need) {
                            s.time_rest.put(i, s.time_rest.get(i) - stream.need);
                            stream.parent.stream_demand.get(i).put(stream.id, 0);
                            s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                            s.t_liu.get(i).add(stream.id);
                            output[i][stream.parent.num].item.put(s.id, output[i][stream.parent.num].item.getOrDefault(s.id, "") + "," + stream.id);
                            continue p;
                        }
                    }
                }
            }
        }

        try {
            SingleStrategy.writeDataToFile(output, out, clients);
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
