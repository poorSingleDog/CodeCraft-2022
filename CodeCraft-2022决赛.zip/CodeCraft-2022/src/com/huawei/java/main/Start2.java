package com.huawei.java.main;

import java.io.IOException;
import java.util.*;

public class Start2 {   //固定上限，旧成本公式
    public void run(String path,String out){
        Server[] servers1 = Server.init(path);
        Client[] clients1 = Client.init(path);
        Server[] servers = Server.getClientInfo(servers1, clients1, path);
        Client[] clients = Client.getServerInfo(servers1, clients1, path);

        for (int i = 0; i < servers.length; i++) {
            for (int j = 0; j < Client.times; j++) {
                servers[i].time_rest.put(j, servers[i].band_width);  //初始化每个边缘的<时刻-余量>表
            }
        }
        SingleStrategy[][] output = new SingleStrategy[Client.times][clients.length];     //[时刻数][客户数] map<边缘id，流id>
        for (int i = 0; i < output.length; i++) {
            for (int j = 0; j < output[0].length; j++) {
                output[i][j] = new SingleStrategy();
            }
        }
        for(int i=0;i<Client.times;i++){
            for(Server s:servers){
                s.receivedStream.put(i,new ArrayList<>());      //给每个边缘在每个时刻都初始化空的Stream容器
            }
        }
        for(int i=0;i<servers.length;i++){
            servers[i].sacriMax=(int)(Client.times*0.05);
        }
        List<Integer> center_times=new ArrayList<>();       //乱分的5个时刻（减1）

        //----------------------------------取一时刻T来定上限---------------------------------------------------------------
        int T=0;        //假设该时刻没有任何边缘是白嫖状态
        List<Stream> current_streams=new ArrayList<>();
        for(Client c:clients){
            for(Map.Entry<String,Integer> entry:c.stream_demand.get(T).entrySet()){
                if(entry.getValue()!=0){
                    current_streams.add(new Stream(c, entry.getKey(), entry.getValue()));
                }
            }
        }
        Collections.sort(current_streams, new Comparator<Stream>() {
            @Override
            public int compare(Stream o1, Stream o2) {
                return o2.need-o1.need;
            }
        });
        l:for(Stream stream:current_streams){
            //对相通的边缘节点进行优先级排序
            for(Server s:servers){      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                s.priority=(2.0*(s.band_width-s.time_rest.get(T)-Server.base_cost)+stream.need)/s.band_width;
            }
            /*for(Server s:servers){
                if(s.clientNum==1)
                    s.priority=1000;
            }*/
            Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                @Override
                public int compare(Server o1, Server o2) {
                    if(o1.priority<o2.priority)
                        return -1;
                    else if(o1.priority>o2.priority)
                        return 1;
                    else
                        return 0;
                }
            });
            for(Server s:stream.parent.serverList){         //开始找最优先的边缘，满足流
                if(s.time_rest.get(T)<stream.need){
                    continue;
                }else if(s.time_rest.get(T)>=stream.need){
                    int trans=stream.need;
                    s.time_rest.put(T,s.time_rest.get(T)-trans);        //记得重置time_rest
                    s.upper_limit=s.band_width-s.time_rest.get(T);      //得到上限
                    continue l;
                }
            }
        }
        for(Server s:servers){
            s.time_rest.put(T,s.band_width);
        }

        //-------------------------------------------开始5%部分----------------------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {
            @Override
            public int compare(Server o1, Server o2) {
                return o2.band_width-o1.band_width;
            }
        });
        for(int i=0;i<servers.length;i++){
            if(servers[i].isDead){
                continue;
            }
            Map<Integer,Integer> t_b=new HashMap<>();
            for(int j=0;j<Client.times;j++){
                int sum=0;
                for(Client c:servers[i].clientList){
                    for(int singleStream:c.stream_demand.get(j).values()){
                        sum+=singleStream;
                    }
                }
                t_b.put(j,sum);
            }
            List<Integer> blackList=new ArrayList<>();      //记录该边缘节点
            List<Map.Entry<Integer, Integer>> T_B = new ArrayList<>(t_b.entrySet());
            Collections.sort(T_B, new Comparator<Map.Entry<Integer, Integer>>() {       //将一列根据相连客户需求和降序排序
                @Override
                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                    return o2.getValue() - o1.getValue();
                }
            });
            for(int j=0;j<T_B.size();j++){
                //&&后面的部分啥意思？
                if(blackList.contains(T_B.get(j).getKey()) && T_B.get(j+1).getValue()>(int)(servers[i].band_width*0.95)){
                    continue;
                }
                blackList.add(T_B.get(j).getKey()+1);       //该时刻的后1时刻加入黑名单（杜绝相邻时刻）
                servers[i].sacri_times.add(T_B.get(j).getKey());
                servers[i].sacrificeNum++;
                //存储该时刻该边缘，连通的未满足的流们
                Map<String,List<Stream>> lius=new HashMap<>();      //<流名-list流>
                for(Client c:servers[i].clientList){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(T_B.get(j).getKey()).entrySet()) {
                        if(entry.getValue()!=0) {
                            if (!lius.keySet().contains(entry.getKey())) {
                                lius.put(entry.getKey(), new ArrayList<>());
                                lius.get(entry.getKey()).add(new Stream(c, entry.getKey(), entry.getValue()));
                            } else {
                                lius.get(entry.getKey()).add(new Stream(c, entry.getKey(), entry.getValue()));
                            }
                        }
                    }
                }
                //《流id-流总量》
                Map<String,Integer> sid_need=new HashMap<>();
                for(Map.Entry<String,List<Stream>> entry:lius.entrySet()){
                    int sum=0;
                    for(Stream stream:entry.getValue()){
                        sum+=stream.need;
                    }
                    sid_need.put(entry.getKey(),sum);
                }
                List<Map.Entry<String,Integer>> Sid_Need=new ArrayList<>(sid_need.entrySet());
                Collections.sort(Sid_Need, new Comparator<Map.Entry<String, Integer>>() {
                    @Override
                    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                        return o2.getValue()-o1.getValue();
                    }
                });
                for(int k=0;k<Sid_Need.size();k++){         //流名为Sid_Need.get(k).getKey()
//                for(String streamId:need_sid.values()){     //一类一类流填
                    //若该束流都可以塞入该边缘
                    if(servers[i].time_rest.get(T_B.get(j).getKey())>=sid_need.get(Sid_Need.get(k).getKey())+(int)(servers[i].band_width*0.05)){
                        for(Stream stream:lius.get(Sid_Need.get(k).getKey())){
                            servers[i].time_rest.put(T_B.get(j).getKey(),servers[i].time_rest.get(T_B.get(j).getKey())-stream.need);
                            servers[i].sendout.put(T_B.get(j).getKey(),servers[i].sendout.getOrDefault(T_B.get(j).getKey(),0)+ stream.need);
                            stream.parent.stream_demand.get(T_B.get(j).getKey()).put(stream.id,0);
                            servers[i].receivedStream.get(T_B.get(j).getKey()).add(stream);     //找准时刻，添加流
                            output[T_B.get(j).getKey()][stream.parent.num].item.put(servers[i].id,output[T_B.get(j).getKey()][stream.parent.num].item.getOrDefault(servers[i].id,"")+","+stream.id);
                        }
                    }else {
                        //需切割该束流,需记录被切流的id
                        servers[i].names.put(T_B.get(j).getKey(),Sid_Need.get(k).getKey());
                        List<Stream> streams=lius.get(Sid_Need.get(k).getKey());
                        Collections.sort(streams, new Comparator<Stream>() {    //从大到小排
                            @Override
                            public int compare(Stream o1, Stream o2) {
                                return o2.need-o1.need;
                            }
                        });
                        for(Stream stream:streams){
                            if(servers[i].time_rest.get(T_B.get(j).getKey())>=stream.need+(int)(servers[i].band_width*0.05)){
                                servers[i].time_rest.put(T_B.get(j).getKey(),servers[i].time_rest.get(T_B.get(j).getKey())-stream.need);
                                servers[i].sendout.put(T_B.get(j).getKey(),servers[i].sendout.getOrDefault(T_B.get(j).getKey(),0)+ stream.need);
                                stream.parent.stream_demand.get(T_B.get(j).getKey()).put(stream.id,0);
                                servers[i].receivedStream.get(T_B.get(j).getKey()).add(stream);     //找准时刻，添加流
                                output[T_B.get(j).getKey()][stream.parent.num].item.put(servers[i].id,output[T_B.get(j).getKey()][stream.parent.num].item.getOrDefault(servers[i].id,"")+","+stream.id);
                            }else {
                                continue;       //该流塞不下则跳到下一个同名流
                            }
                        }
                        break;      //跳到该边缘的下一时刻
                    }
                }
                if(servers[i].sacrificeNum>=servers[i].sacriMax){
                    break;          //跳到下一个边缘节点
                }

            }
        }

        Map<Integer,Integer> t_sumNeed=new HashMap<>();
        for(int i=0;i<Client.times;i++){
            int sum=0;
            for (Client client : clients) {
                for (int need : client.stream_demand.get(i).values()) {
                    sum += need;
                }
            }
            t_sumNeed.put(i,sum);
        }
        List<Map.Entry<Integer,Integer>> T_SUM=new ArrayList<>(t_sumNeed.entrySet());
        Collections.sort(T_SUM, new Comparator<Map.Entry<Integer, Integer>>() {
            @Override
            public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                return o2.getValue()-o1.getValue();
            }
        });
        for(int i=0;i<(int)(Client.times*0.05);i++){      //减一记得改成加一
            center_times.add(T_SUM.get(i).getKey());
        }
        //--------------------------------------------------开始95%部分---------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {
            @Override
            public int compare(Server o1, Server o2) {
                return o1.num - o2.num;
            }
        });
        //------------------填V，牺牲时刻的continue
        /*for(int i=0;i<Client.times;i++) {
            for(Server s:servers){
                s.vrest=Math.min((int)(s.band_width*0.95),Server.base_cost);
            }
            List<Server> aliveS=new ArrayList<>();
            for(int j=0;j<servers.length;j++){
                if(servers[j].sacri_times.contains(i)||servers[j].isDead){
                    continue;
                }else {
                    aliveS.add(servers[j]);
                }
            }
            Collections.sort(aliveS, new Comparator<Server>() {     //给活边缘节点按线数升序排序 (或者先比线数后比容量？)******
                @Override
                public int compare(Server o1, Server o2) {
                    return o1.clientNum-o2.clientNum;
                }
            });
            for (Server s : aliveS) {
                Map<String, Integer> stream_sum = new HashMap<>();      //该边缘连通的每一类流的总和
                for (Client c : s.clientList) {
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                        stream_sum.put(entry.getKey(),stream_sum.getOrDefault(entry.getKey(),0)+ entry.getValue());
                    }
                }
                List<Map.Entry<String,Integer>> Stream_Sum=new ArrayList<>(stream_sum.entrySet());
                Collections.sort(Stream_Sum, new Comparator<Map.Entry<String, Integer>>() {
                    @Override
                    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                        return o2.getValue()-o1.getValue();
                    }
                });
                Collections.sort(s.clientList, new Comparator<Client>() {
                    @Override
                    public int compare(Client o1, Client o2) {
                        return o1.serverNum-o2.serverNum;
                    }
                });
                Boolean key=false;
                for(int j=0;j<Stream_Sum.size();j++){       //流id为Stream_Sum.get(j).getKey()
                    //添加边缘在该时刻的已用流id
                    s.names.get(i).add(Stream_Sum.get(j).getKey());
                    for(Client c:s.clientList){
                        //若该客户有该流的需求，且s能装下
                        if(c.stream_demand.get(i).get(Stream_Sum.get(j).getKey())>0 && s.vrest>=c.stream_demand.get(i).get(Stream_Sum.get(j).getKey())){
                            int trans=c.stream_demand.get(i).get(Stream_Sum.get(j).getKey());
                            c.stream_demand.get(i).put(Stream_Sum.get(j).getKey(),0);
                            s.time_rest.put(i,s.time_rest.get(i)-trans);
                            s.sendout.put(i,s.sendout.getOrDefault(i,0)+trans);
                            s.receivedStream.get(i).add(new Stream(c,Stream_Sum.get(j).getKey(),trans));
                            output[i][c.num].item.put(s.id,output[i][c.num].item.getOrDefault(s.id,"")+","+Stream_Sum.get(j).getKey());
                        }else {
                            key=true;
                        }
                    }
                    if(key){    //若当前类的流已不能全部满足，则不再去找下一类的流
                        break;
                    }
                }
            }
        }*/

        //顺序遍历时刻，最先判断是否是center_times的时刻，然后先填牺牲边缘的剩余空间，再填上限，流无处可去再扩上限
        for(int i=0;i<Client.times;i++){
            System.out.println(i);
            for(Server s:servers){
                s.liu_max=new HashMap<>();      //每个时刻开始都初始化每个边缘的已填流
            }
            if(center_times.contains(i)){       //策略为乱分
                if(i!=0){
                    for(Server s:servers){      //更新该时刻的余量，减去缓存
                        s.time_rest.put(i,s.time_rest.get(i)-(int)(0.05*(s.band_width-s.time_rest.get(i-1))));
                    }
                }
                for(Server s:servers){
                    if(s.sacri_times.contains(i)){
                        Collections.sort(s.clientList, new Comparator<Client>() {
                            @Override
                            public int compare(Client o1, Client o2) {
                                return o1.serverNum-o2.serverNum;
                            }
                        });
                        for(Client c:s.clientList){
                            for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                                if(entry.getValue()!=0){
                                    if(s.time_rest.get(i)>=entry.getValue()){   //能装下
                                        int trans=entry.getValue();
                                        c.stream_demand.get(i).put(entry.getKey(),0);
                                        s.time_rest.put(i,s.time_rest.get(i)-trans);
                                        s.sendout.put(i,s.sendout.getOrDefault(i,0)+trans);
                                        s.receivedStream.get(i).add(new Stream(c, entry.getKey(), trans));
                                        output[i][c.num].item.put(s.id,output[i][c.num].item.getOrDefault(s.id,"")+","+entry.getKey());

                                    }else {
                                        continue;       //跳到该客户该时刻的下一个未满足流
                                    }
                                }
                            }
                        }

                    }
                }
                //填上限，再扩上限
                List<Stream> liu=new ArrayList<>();         //存储i时刻中所有未满足的流
                for(Client c:clients){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                p:for(Stream stream:liu){         //上限以内，用什么规定边缘节点优先级?(边缘节点线数少的优先)
                    Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                        @Override
                        public int compare(Server o1, Server o2) {
                            return o1.clientNum-o2.clientNum;
                        }
                    });
                    for(Server s:stream.parent.serverList){
                        if(s.sacri_times.contains(i)){      //牺牲的边缘节点不参与
                            continue ;
                        }
                        if(s.upper_limit-(s.band_width-s.time_rest.get(i))<stream.need) {        //可用量=上限-已用
                            continue;
                        }else if(s.upper_limit-(s.band_width-s.time_rest.get(i))>=stream.need){
                            int trans=stream.need;
                            s.time_rest.put(i,s.time_rest.get(i)-trans);
                            stream.parent.stream_demand.get(i).put(stream.id,0);
                            s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                            output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                            continue p;
                        }
                    }
                    //扩展最优先边缘节点的上限
                    if(stream.parent.stream_demand.get(i).get(stream.id)>0){
                        for(Server s:servers){      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                            s.priority=(2.0*(s.band_width-s.time_rest.get(i)-Server.base_cost)+stream.need)/s.band_width;
                        }


                        Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                            @Override
                            public int compare(Server o1, Server o2) {
                                if(o1.priority<o2.priority)
                                    return -1;
                                else if(o1.priority>o2.priority)
                                    return 1;
                                else
                                    return 0;
                            }
                        });
                        for(Server s:stream.parent.serverList){
//                            if(s.sacri_times.contains(i)){      //牺牲节点不参与
//                                continue ;
//                            }
                            if(s.time_rest.get(i)<stream.need)
                                continue ;
                            else if(s.time_rest.get(i)>=stream.need){
                                s.time_rest.put(i,s.time_rest.get(i)-stream.need);
                                //s.upper_limit=s.band_width-s.time_rest.get(i);
                                stream.parent.stream_demand.get(i).put(stream.id,0);
                                s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                                output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                                continue p;
                            }
                        }
                        System.out.println("扩上限时流也无处可去，error");
                        return;
                    }
                }

                System.out.print("乱分时刻");
            }else{                     //策略为流从大到小填，先填上限， 分到上限的过程中一束一束分
                if(i!=0){
                    for(Server s:servers){
                        s.time_rest.put(i,s.time_rest.get(i)-(int)(0.05*(s.band_width-s.time_rest.get(i-1))));
                    }
                }
                //先填补牺牲边缘的剩余空间
                for(Server s:servers){
                    if(s.sacri_times.contains(i)){
                        //存储该时刻该边缘，连通的未满足的流们
//                        Map<String,List<Stream>> lius=new HashMap<>();      //<流名-list流>
//                        for(Client c:servers[i].clientList){
//                            for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()) {
//                                if(entry.getValue()!=0) {
//                                    if (!lius.keySet().contains(entry.getKey())) {
//                                        lius.put(entry.getKey(), new ArrayList<>());
//                                        lius.get(entry.getKey()).add(new Stream(c, entry.getKey(), entry.getValue()));
//                                    } else {
//                                        lius.get(entry.getKey()).add(new Stream(c, entry.getKey(), entry.getValue()));
//                                    }
//                                }
//                            }
//                        }
//                        List<Stream> before_liu=lius.get(s.names.get(i));
//                        int sum=0;
//                        for(Stream stream:before_liu){
//                            sum+=stream.need;
//                        }
//                        if(s.time_rest.get(i)>=sum){        //可以整束都进去
//                            for(Stream stream:before_liu){
//                                int trans=stream.need;
//                                s.time_rest.put(i,s.time_rest.get(i)-trans);
//                                stream.parent.stream_demand.get(i).put(stream.id,0);
//                                s.sendout.put(i,servers[i].sendout.getOrDefault(i,0)+ stream.need);
//                                s.receivedStream.get(i).add(stream);
//                                output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
//                            }
                        //任意选取线少的流填？
                        Collections.sort(s.clientList, new Comparator<Client>() {
                            @Override
                            public int compare(Client o1, Client o2) {
                                return o1.serverNum-o2.serverNum;
                            }
                        });
                        for(Client c:s.clientList){             //按线数从小到大遍历连通的client
                            for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                                if(entry.getValue()!=0){
                                    if(s.time_rest.get(i)>=entry.getValue()){
                                        int trans= entry.getValue();
                                        s.time_rest.put(i,s.time_rest.get(i)-trans);
                                        c.stream_demand.get(i).put(entry.getKey(), 0);
                                        s.sendout.put(i,s.sendout.getOrDefault(i,0)+ trans);
                                        s.receivedStream.get(i).add(new Stream(c, entry.getKey(), entry.getValue()));
                                        output[i][c.num].item.put(s.id,output[i][c.num].item.getOrDefault(s.id,"")+","+entry.getKey());
                                    }else {
                                        continue;
                                    }
                                }
                            }
                        }

//                        }else {                             //不可以整束都进去
//                            for(Stream stream:before_liu){
//                                if(s.time_rest.get(i)>=stream.need){
//                                    int trans=stream.need;
//                                    s.time_rest.put(i,s.time_rest.get(i)-trans);
//                                    stream.parent.stream_demand.get(i).put(stream.id,0);
//                                    s.sendout.put(i,s.sendout.getOrDefault(i,0)+ stream.need);
//                                    s.receivedStream.get(i).add(stream);
//                                    output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
//
//                                }else {
//                                    continue;           //跳到下一个同名流
//                                }
//                            }
//                        }
                    }
                }

                //一类一类流填上限，牺牲边缘不参与
                Map<String,List<Stream>> lius=new HashMap<>();      //《流id-流list》
                for(Client c:clients){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()) {
                        if(entry.getValue()!=0) {
                            if (!lius.keySet().contains(entry.getKey())) {
                                lius.put(entry.getKey(), new ArrayList<>());
                                lius.get(entry.getKey()).add(new Stream(c, entry.getKey(), entry.getValue()));
                            } else {
                                lius.get(entry.getKey()).add(new Stream(c, entry.getKey(), entry.getValue()));
                            }
                        }
                    }
                }
                for(int j=0;j<200;j++) {
                    String chosenStream = "";         //选出总量最大的一类流
                    int sum_max = 0;
                    for (Map.Entry<String, List<Stream>> entry : lius.entrySet()) {
                        int sum = 0;
                        for (Stream temp : entry.getValue()) {
                            sum += temp.need;
                        }
                        if (sum > sum_max) {
                            sum_max = sum;
                            chosenStream = entry.getKey();
                        }
                    }
                    if(chosenStream.equals("")){
                        System.out.println(j);
                        break;
                    }
                    //《边缘节点编号-含该类流的量》
                    Map<Integer,Integer> serverNum_burden=new HashMap<>();
                    for(int k=0;k<servers.length;k++) {
                        if(servers[k].sacri_times.contains(i)){
                            continue;
                        }
                        int burden=0;
                        for (Stream stream : lius.get(chosenStream)) {
                            if(servers[k].clientList.contains(stream.parent)){
                                burden+=stream.need;
                            }
                        }
                        serverNum_burden.put(k,burden);
                    }
                    //《server编号-它连通的一束流总量》
                    List<Map.Entry<Integer,Integer>> Snum_Burden=new ArrayList<>(serverNum_burden.entrySet());
                    Collections.sort(Snum_Burden, new Comparator<Map.Entry<Integer, Integer>>() {
                        @Override
                        public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                            return o2.getValue()-o1.getValue();
                        }
                    });

                    for(int m=0;m<Snum_Burden.size();m++){
                        //观察servers[Snum_Burden.get(m).getKey()]能不能接受属于它的一束流，能则break
                        if(servers[Snum_Burden.get(m).getKey()].upper_limit-(servers[Snum_Burden.get(m).getKey()].band_width-servers[Snum_Burden.get(m).getKey()].time_rest.get(i))>=Snum_Burden.get(m).getValue()){
                            List<Stream> delete=new ArrayList<>();
                            for(Stream stream:lius.get(chosenStream)){
                                if(servers[Snum_Burden.get(m).getKey()].clientList.contains(stream.parent)) {
                                    servers[Snum_Burden.get(m).getKey()].time_rest.put(i, servers[Snum_Burden.get(m).getKey()].time_rest.get(i) - stream.need);
                                    servers[Snum_Burden.get(m).getKey()].sendout.put(i, servers[Snum_Burden.get(m).getKey()].sendout.getOrDefault(i, 0) + stream.need);
                                    stream.parent.stream_demand.get(i).put(stream.id, 0);
                                    servers[Snum_Burden.get(m).getKey()].receivedStream.get(i).add(stream);     //找准时刻，添加流
                                    output[i][stream.parent.num].item.put(servers[Snum_Burden.get(m).getKey()].id, output[i][stream.parent.num].item.getOrDefault(servers[Snum_Burden.get(m).getKey()].id, "") + "," + stream.id);
                                    delete.add(stream);
                                    //填过的这类流的最大量
                                    if(servers[Snum_Burden.get(m).getKey()].liu_max.containsKey(stream.id)){
                                        servers[Snum_Burden.get(m).getKey()].liu_max.put(stream.id,Math.max(servers[Snum_Burden.get(m).getKey()].liu_max.get(stream.id), stream.need));
                                    }else {
                                        servers[Snum_Burden.get(m).getKey()].liu_max.put(stream.id, stream.need);
                                    }

                                }
                            }
                            for(Stream stream:delete) {
                                lius.get(chosenStream).remove(stream);      //lius是每时刻得到一次，因此同一时刻内要remove操作
                            }
                            break;
                        }
                    }
                }


                //选出单位成本最小的边缘，选出它连通的体量最大的一束流（当流都被满足，跳出）
                /*List<Server> usefulS=new ArrayList<>();
                for(Server s:servers){
                    if(!s.sacri_times.contains(i)){
                        usefulS.add(s);
                    }
                }
                while (true){
                    int SNum = -1;
                    double min_prio = 9999999;
                    for (Server s : usefulS) {
                        s.priority = (2.0 * (s.band_width - s.time_rest.get(i) - Server.base_cost)) / s.band_width;
                        if (s.priority < min_prio) {
                            SNum = s.num;
                            min_prio = s.priority;
                        }
                    }
                    Map<String, Integer> streamId_need = new HashMap<>();
                    for (Client c : servers[SNum].clientList) {
                        for (Map.Entry<String, Integer> entry : c.stream_demand.get(i).entrySet()) {
                            if (entry.getValue() != 0) {
                                streamId_need.put(entry.getKey(), streamId_need.getOrDefault(entry.getKey(), 0) + entry.getValue());
                            }
                        }
                    }

                    List<Map.Entry<String, Integer>> StreamId_Need = new ArrayList<>(streamId_need.entrySet());
                    Collections.sort(StreamId_Need, new Comparator<Map.Entry<String, Integer>>() {
                        @Override
                        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                            return o2.getValue() - o1.getValue();
                        }
                    });
                    for (int k = 0; k < StreamId_Need.size(); k++) {
                        if (servers[SNum].time_rest.get(i) >= StreamId_Need.get(k).getValue()) {
                            List<Stream> delete = new ArrayList<>();
                            for (Stream stream : lius.get(StreamId_Need.get(k).getKey())) {
                                if (servers[SNum].clientList.contains(stream.parent)) {
                                    servers[SNum].time_rest.put(i, servers[SNum].time_rest.get(i) - stream.need);
                                   servers[SNum].sendout.put(i, servers[SNum].sendout.getOrDefault(i, 0) + stream.need);
                                    stream.parent.stream_demand.get(i).put(stream.id, 0);
                                    servers[SNum].receivedStream.get(i).add(stream);     //找准时刻，添加流
                                    servers[SNum].upper_limit = Math.max(servers[SNum].upper_limit, servers[SNum].band_width - servers[SNum].time_rest.get(i));
                                    output[i][stream.parent.num].item.put(servers[SNum].id, output[i][stream.parent.num].item.getOrDefault(servers[SNum].id, "") + "," + stream.id);
                                    delete.add(stream);
                                }
                            }
                            for (Stream stream : delete) {
                                lius.get(StreamId_Need.get(k).getKey()).remove(stream);
                            }
                            break;
                        }
                    }
                    int sumNeed=0;
                    for(Client c:clients){
                        for(int need:c.stream_demand.get(i).values()){
                            sumNeed+=need;
                        }
                    }
                    if(sumNeed==0){
                        break;
                    }
                    if(streamId_need.size()==0){
                        usefulS.remove(servers[SNum]);
                    }
                }*/


                //填上限，再扩上限
                List<Stream> liu=new ArrayList<>();         //存储i时刻中所有未满足的流
                for(Client c:clients){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                g:for(Stream stream:liu) {         //上限以内，用什么规定边缘节点优先级?(边缘节点线数少的优先)

                    for(Server s:servers){      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth+A*(查表该id-该流大小)或0
                        s.priority=(2.0*(s.band_width-s.time_rest.get(i)-Server.base_cost)+stream.need)/s.band_width+Server.center_cost* (s.liu_max.getOrDefault(stream.id,0)> stream.need?0: (stream.need-s.liu_max.getOrDefault(stream.id,0)));
                    }
                    Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                        @Override
                        public int compare(Server o1, Server o2) {
                            if(o1.priority<o2.priority)
                                return -1;
                            else if(o1.priority>o2.priority)
                                return 1;
                            else
                                return 0;
                        }
                    });
                    for (Server s : stream.parent.serverList) {
                        if (s.sacri_times.contains(i)) {      //牺牲的边缘节点不参与
                            continue;
                        }
                        if (s.time_rest.get(i) < stream.need) {        //可用量=上限-已用
                            continue;
                        } else if (s.time_rest.get(i) >= stream.need) {
                            int trans = stream.need;
                            s.time_rest.put(i, s.time_rest.get(i) - trans);
                            stream.parent.stream_demand.get(i).put(stream.id, 0);
                            s.receivedStream.get(i).add(stream);        //找准时刻，添加流
//                            s.upper_limit=Math.max(s.upper_limit,s.band_width-s.time_rest.get(i));
                            output[i][stream.parent.num].item.put(s.id, output[i][stream.parent.num].item.getOrDefault(s.id, "") + "," + stream.id);
                            if(s.liu_max.containsKey(stream.id)){
                                s.liu_max.put(stream.id,Math.max(s.liu_max.get(stream.id),stream.need));
                            }else {
                                s.liu_max.put(stream.id,stream.need);
                            }
                            continue g;
                        }
                    }


                }
                System.out.print("一束束分时刻");
            }
            for(Client c:clients){
                for(int need:c.stream_demand.get(i).values()){
                    if(need!=0){
                        int p=0;
                        int q=9/p;
                    }
                }
            }
        }
        for(Server s:servers){
            System.out.println("upper:"+s.upper_limit);
        }
        try {
            SingleStrategy.writeDataToFile(output, out, clients);
        }catch (IOException e){
            e.printStackTrace();
        }



    }


}
