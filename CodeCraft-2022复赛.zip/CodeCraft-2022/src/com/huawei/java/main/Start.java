package com.huawei.java.main;

import java.io.IOException;
import java.util.*;

public class Start {
    public String deleteStream(String originStr,String streamId){
        String res="";
        String[] streams=originStr.split(",");      //streams[0]是""
        for(int i=1;i<streams.length;i++){
            if(streams[i].equals(streamId)){
                continue;
            }
            res+=","+streams[i];
        }
        return res;
    }
    public int spend(int Wj,int cj,int v){
        return (Wj-v)*(Wj-v)/cj+Wj;
    }

    public void run(String path,String out){
        Server[] servers1 = Server.init(path);
        Client[] clients1 = Client.init(path);
        Server[] servers = Server.getClientInfo(servers1, clients1, path);
        Client[] clients = Client.getServerInfo(servers1, clients1, path);

//        Server[] servers=Server.abandon(old_servers,1);     //线数只有1的边缘被禁用
//        for(int i=0;i<servers.length;i++){
//            servers[i].num=i;
//        }
//        List<Server> abandonS=new ArrayList<>();
//        k:for(Server s:old_servers){
//            for(Server ss:servers){
//                if(s==ss)
//                    continue k;
//            }
//            abandonS.add(s);
//        }
//        for(Client c:clients){
//            for(Server s:abandonS){
//                c.serverList.remove(s);
//            }
//        }
//        for(Client c:clients){
//            c.serverNum=c.serverList.size();
//        }

        int sacrificeMax = (int) (Client.times * 0.05);         //同一个边缘节点最大白嫖次数
        int[][] gragh = Server.getGragh(servers1, clients1, path);                    //存放每个客户的原始边缘节点列表
        int[] static_servernum = new int[clients.length];         //存放每个客户的原始线数
        for (int i = 0; i < clients.length; i++) {
            static_servernum[i] = clients[i].serverNum;
        }
        int[] static_clientnum = new int[servers.length];
        for (int i = 0; i < servers.length; i++) {
            static_clientnum[i] = servers[i].clientNum;
        }
        for (int i = 0; i < servers.length; i++) {
            for (int j = 0; j < Client.times; j++) {
                servers[i].time_rest.put(j, servers[i].band_width);  //初始化每个边缘的<时刻-余量>表
            }
        }
        SingleStrategy[][] output = new SingleStrategy[Client.times][clients.length];     //[时刻数][客户数] map<边缘id，流id>
        for (int i = 0; i < output.length; i++) {
            for (int j = 0; j < output[0].length; j++) {
                output[i][j] = new SingleStrategy();
            }
        }
        for(int i=0;i<Client.times;i++){
            for(Server s:servers){
                s.receivedStream.put(i,new ArrayList<>());      //给每个边缘在每个时刻都初始化空的Stream容器
            }
        }
        //-------------------------------------------开始5%部分----------------------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {         //test:边缘节点按照容量降序排序
            @Override
            public int compare(Server o1, Server o2) {
                return o2.band_width - o1.band_width;
            }
        });
        for(int i=0;i<servers.length;i++){      //对每一列
            if(servers[i].isDead){
                continue;
            }
            Map<Integer,Integer> t_b=new HashMap<>();
            for(int j=0;j<Client.times;j++){
                int sum=0;
                for(Client c:servers[i].clientList){
                    for(int singleStream:c.stream_demand.get(j).values()){
                        sum+=singleStream;
                    }
                }
                t_b.put(j,sum);
            }
            List<Map.Entry<Integer, Integer>> T_B = new ArrayList<>(t_b.entrySet());
            Collections.sort(T_B, new Comparator<Map.Entry<Integer, Integer>>() {       //将一列根据相连客户需求和降序排序
                @Override
                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                    return o2.getValue() - o1.getValue();
                }
            });
            for(int j=0;j<sacrificeMax;j++){            //对这一列的前5%行进行分配,时刻=T_B.get(j).getKey()
                servers[i].sacri_times.add(T_B.get(j).getKey());
                servers[i].sacrificeNum++;
                Collections.sort(servers[i].clientList, new Comparator<Client>() {      //对该边缘下面的客户进行线数升序排序
                    @Override
                    public int compare(Client o1, Client o2) {
                        return o1.serverNum - o2.serverNum;
                    }
                });
                List<Stream> liu=new ArrayList<>();         //存储i时刻中所有未满足的流
                for(Client c:servers[i].clientList){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(T_B.get(j).getKey()).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                //找server[i]连通的流中最大的流
                for(Stream stream:liu){
                    if(servers[i].time_rest.get(T_B.get(j).getKey())>=stream.need){
                        servers[i].time_rest.put(T_B.get(j).getKey(),servers[i].time_rest.get(T_B.get(j).getKey())-stream.need);
                        stream.parent.stream_demand.get(T_B.get(j).getKey()).put(stream.id,0);
                        servers[i].receivedStream.get(T_B.get(j).getKey()).add(stream);     //找准时刻，添加流
                        output[T_B.get(j).getKey()][stream.parent.num].item.put(servers[i].id,output[T_B.get(j).getKey()][stream.parent.num].item.getOrDefault(servers[i].id,"")+","+stream.id);
                    }else if(servers[i].time_rest.get(T_B.get(j).getKey())<stream.need){
                        continue;
                    }
                }
            }
        }
        //--------------------------------------------------开始95%部分-----------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {         //将servers排回原来顺序
            @Override
            public int compare(Server o1, Server o2) {
                return o1.num - o2.num;
            }
        });
        for(int i=0;i<Client.times;i++){        //-------------填掉每个边缘节点的V
            for(Server s:servers)
                s.vrest=Math.min(Server.base_cost,s.band_width);       //每时刻开始，边缘节点的上限设为v和带宽的较小值
            List<Server> aliveS=new ArrayList<>();
            for(int j=0;j<servers.length;j++){
                if(servers[j].sacri_times.contains(i)||servers[j].isDead){
                    continue;
                }else {
                    aliveS.add(servers[j]);
                }
            }
            Collections.sort(aliveS, new Comparator<Server>() {     //给活边缘节点按线数升序排序 (或者先比线数后比容量？)******
                @Override
                public int compare(Server o1, Server o2) {
                    return o1.clientNum-o2.clientNum;
                }
            });
            for(Server s:aliveS){
                List<Stream> liu=new ArrayList<>();
                for(Client c:s.clientList){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                for(Stream stream:liu){
                    if(s.vrest<stream.need){
                        continue;
                    }else if(s.vrest>=stream.need){
                        s.vrest-=stream.need;
                        s.time_rest.put(i,s.time_rest.get(i)-stream.need);
                        stream.parent.stream_demand.get(i).put(stream.id,0);
                        s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                        output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                    }
                }
            }

            //开始检查客户下的流是否都已经为0,把未得到满足的流id存起来，统一处理

        }

        //----------------------------------------------------填完V之后-------------------------------------------------------
        Map<Integer,Integer> map=new HashMap<>();   //《时刻-剩余总需求》
        for(int i=0;i<Client.times;i++){
            int sum=0;
            for(Client c:clients){
                for(int streamSize:c.stream_demand.get(i).values()){
                    sum+=streamSize;
                }
            }
            map.put(i,sum);
        }
        List<Map.Entry<Integer,Integer>> MAP=new ArrayList<>(map.entrySet());
        Collections.sort(MAP, new Comparator<Map.Entry<Integer, Integer>>() {
            @Override
            public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                return o2.getValue()-o1.getValue();
            }
        });
//        int T=MAP.get(0).getKey();
        int T=1;
        //进入剩余需求量最大的时刻，初始化上限, stream<客户,流id,流大小>
        List<Stream> streams=new ArrayList<>();
        for(Client c:clients){
            for(Map.Entry<String,Integer> entry:c.stream_demand.get(T).entrySet()){
                if(entry.getValue()!=0){
                    streams.add(new Stream(c, entry.getKey(), entry.getValue()));
                }
            }
        }
        Collections.sort(streams, new Comparator<Stream>() {
            @Override
            public int compare(Stream o1, Stream o2) {
                return o2.need-o1.need;
            }
        });
        l:for(Stream stream:streams){
            //对相通的边缘节点进行优先级排序
            for(Server s:servers){      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                s.priority=(2.0*(s.band_width-s.time_rest.get(T)-Server.base_cost)+stream.need)/s.band_width;
            }
            for(Server s:servers){
                if(s.clientNum==1)
                    s.priority=1000;
            }

            Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                @Override
                public int compare(Server o1, Server o2) {
//                    return (int) (o1.priority-o2.priority);
                    if(o1.priority<o2.priority)
                        return -1;
                    else if(o1.priority>o2.priority)
                        return 1;
                    else
                        return 0;
                }
            });
            for(Server s:stream.parent.serverList){         //开始找最优先的边缘，满足流
                if(s.time_rest.get(T)<stream.need){
                    continue;
                }else if(s.time_rest.get(T)>=stream.need){
                    int trans=stream.need;
                    s.time_rest.put(T,s.time_rest.get(T)-trans);
                    s.upper_limit=s.band_width-s.time_rest.get(T);
                    stream.parent.stream_demand.get(T).put(stream.id,0);
                    s.receivedStream.get(T).add(stream);        //找准时刻，添加流
                    output[T][stream.parent.num].item.put(s.id,output[T][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                    continue l;
                }
            }
        }
        //--------------------------------其余时刻填上限并扩展
        for(int i=0;i<Client.times;i++){
            if(i==T)
                continue;
            List<Stream> liu=new ArrayList<>();         //存储i时刻中所有未满足的流
            for(Client c:clients){
                for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                    if(entry.getValue()!=0){
                        liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                    }
                }
            }
            Collections.sort(liu, new Comparator<Stream>() {
                @Override
                public int compare(Stream o1, Stream o2) {
                    return o2.need-o1.need;
                }
            });
            p:for(Stream stream:liu){         //上限以内，用什么规定边缘节点优先级?(边缘节点线数少的优先)
                Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                    @Override
                    public int compare(Server o1, Server o2) {
                        return o1.clientNum-o2.clientNum;
                    }
                });
                for(Server s:stream.parent.serverList){
                    if(s.upper_limit-(s.band_width-s.time_rest.get(i))<stream.need) {        //可用量=上限-已用
                        continue;
                    }else if(s.upper_limit-(s.band_width-s.time_rest.get(i))>=stream.need){
                        int trans=stream.need;
                        s.time_rest.put(i,s.time_rest.get(i)-trans);
                        stream.parent.stream_demand.get(i).put(stream.id,0);
                        s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                        output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                        continue p;
                    }
                }
                //扩展最优先边缘节点的上限
                if(stream.parent.stream_demand.get(i).get(stream.id)>0){
                    for(Server s:servers){      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                        s.priority=(2.0*(s.band_width-s.time_rest.get(i)-Server.base_cost)+stream.need)/s.band_width;
                    }
                    for(Server s:servers){
                        if(s.clientNum==1)
                            s.priority=1000;

                    }

                    Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                        @Override
                        public int compare(Server o1, Server o2) {
                            if(o1.priority<o2.priority)
                                return -1;
                            else if(o1.priority>o2.priority)
                                return 1;
                            else
                                return 0;
                        }
                    });
                    for(Server s:stream.parent.serverList){
                        if(s.time_rest.get(i)<stream.need)
                            continue ;
                        else if(s.time_rest.get(i)>=stream.need){
                            s.time_rest.put(i,s.time_rest.get(i)-stream.need);
                            s.upper_limit=s.band_width-s.time_rest.get(i);
                            stream.parent.stream_demand.get(i).put(stream.id,0);
                            s.receivedStream.get(i).add(stream);        //找准时刻，添加流
                            output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                            continue p;
                        }
                    }

                }
            }

        }
        //-------------------------------------------------二次分配，削峰-------------------------------------------------------
        for(Server s:servers){
            for(Map.Entry<Integer,Integer> entry:s.time_rest.entrySet()){
                if(s.sacri_times.contains(entry.getKey())){     //如果该时刻是用于牺牲的时刻，不加入sendout，自闭节点的sendout为空
                    continue;
                }
                s.sendout.put(entry.getKey(),s.band_width-entry.getValue());    //用量=总带宽-剩余量
                s.allsend+=s.band_width-entry.getValue();
            }
        }
        for(Server s:servers){
            s.SendOut=new ArrayList<>(s.sendout.entrySet());
            //根据用量从大到小排,有95%时刻项
            Collections.sort(s.SendOut, new Comparator<Map.Entry<Integer, Integer>>() {
                @Override
                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                    return o2.getValue()-o1.getValue();
                }
            });
            s.priority=s.SendOut.get(0).getValue()-s.allsend/(Client.times*0.95);       //该优先级不知道有没有用？
        }
        List<Server> liveS=new ArrayList<>();       //用来互相转移的Server
        for(Server s:servers){
            if(s.isDead)
                continue;
            liveS.add(s);
        }
        Collections.sort(liveS, new Comparator<Server>() {
            @Override
            public int compare(Server o1, Server o2) {
                if(o2.priority>o1.priority)
                    return 1;
                else if(o2.priority<o1.priority)
                    return -1;
                else
                    return 0;
            }
        });
        //正式开始二次分配
        int x= (int) (Client.times*0.01);
        int dd=0;
        while (true){
            for(Server s:liveS){        //第一层
                //给SendOut排序
                s.SendOut=new ArrayList<>(s.sendout.entrySet());
                Collections.sort(s.SendOut, new Comparator<Map.Entry<Integer, Integer>>() {
                    @Override
                    public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                        return o2.getValue()-o1.getValue();
                    }
                });

                q:for(int m=0;m<x;m++){       //第二层
                    //若此刻用量与平均用量相差不大，则continue      此刻用量-平均用量<平均用量*0.1
                    if(s.SendOut.get(m).getValue()-s.allsend/(int)(Client.times*0.95) < s.allsend/(int)(Client.times*0.95)*0.05){
                        continue ;
                    }
                    int t=s.SendOut.get(m).getKey();
                    int aim=s.SendOut.get(m).getValue()-s.allsend/(int)(Client.times*0.95);       //目标削弱值
                    //将该边缘在该时刻接收的流按从大到小排序
                    Collections.sort(s.receivedStream.get(t), new Comparator<Stream>() {
                        @Override
                        public int compare(Stream o1, Stream o2) {
                            return o2.need-o1.need;
                        }
                    });
                    List<Stream> temp=new ArrayList<>(s.receivedStream.get(t));
                    for(Stream stream:temp){         //第三层
                        List<Server> other=new ArrayList<>();
                        for(Server otherS:stream.parent.serverList){          //第四层，在所有可接收的边缘节点中选 此时用量与最大用量相比差距最大的
                            if(otherS.id==s.id)
                                continue;
                            //若转移到otherS时，otherS在该时刻的用量仍然不超过它的第x大（或者最大？）的用量，则把stream从s转移到otherS
                            if(otherS.time_rest.get(t)>stream.need && otherS.sendout.get(t)+stream.need<=otherS.SendOut.get(0).getValue()){
                                other.add(otherS);
                            }
                        }
                        //排接收流的边缘优先级（与均值比还是与94%位置的用量比？？）
                        Collections.sort(other, new Comparator<Server>() {
                            @Override
                            public int compare(Server o1, Server o2) {
                                return (o2.SendOut.get(0).getValue()-o2.sendout.get(t))-(o1.SendOut.get(0).getValue()-o1.sendout.get(t));
                            }
                        });
                        for(Server otherS:other) {
                            //边缘s在t时刻的用量减少
                            s.sendout.put(t, s.sendout.get(t) - stream.need);
                            //边缘s在t时刻接收的流删去
                            s.receivedStream.get(t).remove(stream);
                            //边缘s在t时刻的剩余量加上
                            s.time_rest.put(t, s.time_rest.get(t) + stream.need);
                            //边缘s在所有95%时刻的用量减去
                            s.allsend -= stream.need;

                            //边缘otherS在t时刻的用量增加
                            otherS.sendout.put(t, otherS.sendout.get(t) + stream.need);
                            //边缘otherS在t时刻接收的流加上
                            otherS.receivedStream.get(t).add(stream);
                            //边缘otherS在t时刻的剩余量减去
                            otherS.time_rest.put(t, otherS.time_rest.get(t) - stream.need);
                            //边缘otherS在所有95%时刻的用量增加
                            otherS.allsend += stream.need;
//                            //更新边缘otherS的SendOut
//                            otherS.SendOut=new ArrayList<>(otherS.sendout.entrySet());
//                            Collections.sort(otherS.SendOut, new Comparator<Map.Entry<Integer, Integer>>() {
//                                @Override
//                                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
//                                    return o2.getValue()-o1.getValue();
//                                }
//                            });

                            //边缘otherS中添加stream的id
                            output[t][stream.parent.num].item.put(otherS.id, output[t][stream.parent.num].item.getOrDefault(otherS.id, "") + "," + stream.id);
                            //边缘s中删除stream的id，若是边缘s的唯一则除去边缘s
                            String update = deleteStream(output[t][stream.parent.num].item.get(s.id), stream.id);
                            if (update.equals("")) {
                                output[t][stream.parent.num].item.remove(s.id);
                            } else {
                                output[t][stream.parent.num].item.put(s.id, update);
                            }
                            System.out.println("time:" + t + " stream:" + stream.id + " 从" + s.id + " 到" + otherS.id);

                            aim -= stream.need;
                            if (aim <= 0)
                                continue q;
                            break;
                        }


                    }
                }
            }
            System.out.println(dd++);
            if(dd==200)
                break;
        }



//        for(int i=0;i<output.length;i++){
//            for(int j=0;j<output[0].length;j++){
//                System.out.print(clients[j].id+":");
//                for(Map.Entry<String ,String> entry:output[i][j].item.entrySet()){
//                    System.out.print("<"+entry.getKey()+entry.getValue()+">");
//                }
//                System.out.println();
//            }
//        }
        try {
            SingleStrategy.writeDataToFile(output, out, clients);
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
