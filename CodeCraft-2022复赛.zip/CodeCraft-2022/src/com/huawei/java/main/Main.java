package com.huawei.java.main;
public class Main {

	public static void main(String[] args) {
		Start test = new Start();
		test.run("/data", "/output/solution.txt");

//		System.out.println(test.deleteStream(",54545,44,98k,ouh","98"));
//		String path="data";
//		Server[] servers1 = Server.init(path);
//		Client[] clients1 = Client.init(path);
//		Server[] old_servers = Server.getClientInfo(servers1, clients1, path);
//		Client[] clients = Client.getServerInfo(servers1, clients1, path);
//		int dead=0;
//		for(Server s:old_servers){
//			if(s.isDead)
//				dead++;
//		}
//		System.out.println(dead);
//
//		Server[] servers=Server.abandon(old_servers,1);
//		System.out.println(old_servers.length);
//		System.out.println(servers.length);

	}
}
