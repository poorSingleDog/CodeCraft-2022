package com.huawei.java.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Readfile {
    public static String[][] readcsv(String path){
        String line;
        String cvsSplitBy = ",";

        try(LineNumberReader lineNumberReader=new LineNumberReader(new FileReader(path))){
            lineNumberReader.skip(Long.MAX_VALUE);
            int n=lineNumberReader.getLineNumber();
            String[][] res=new String[n][];            //不知道几列
            try (BufferedReader br = new BufferedReader(new FileReader(path))) {
                int i=0;
                while ((line = br.readLine()) != null) {
                    // use comma as separator
                    String[] item = line.split(cvsSplitBy);
                    res[i]=item;
                    i++;

                }
                return res;

            } catch (IOException e) {
                e.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public static int[] readini(String path) {
        int[] res=new int[2];
        String line;
        String temp_qos="";
        String base_cost="";
        StringBuffer qos_constraint=new StringBuffer();
        StringBuffer v=new StringBuffer();
        Boolean k=false;
        Boolean f=false;
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            int i = 0;
            while ((line = br.readLine()) != null) {
                // use comma as separator
                if (i == 1) {
                    temp_qos = line;
                }
                if(i==2){
                    base_cost=line;
                    break;
                }

                i++;
            }
            for(int j=0;j<temp_qos.length();j++){

                if(k==true){
                    qos_constraint.append(temp_qos.charAt(j));
                }
                if(temp_qos.charAt(j)=='=')
                    k=true;

            }
            for(int j=0;j<base_cost.length();j++){

                if(f==true){
                    v.append(base_cost.charAt(j));
                }
                if(base_cost.charAt(j)=='=')
                    f=true;

            }
            res[0]=Integer.valueOf(String.valueOf(qos_constraint));
            res[1]=Integer.valueOf(String.valueOf(v));
            return res;
        }catch (Exception e){
            e.printStackTrace();
        }
        return res;
    }

    public static void main(String[] args) {
        int[] res=readini("data/config.ini");
        System.out.println(res[0]);
        System.out.println(res[1]);
    }
}
