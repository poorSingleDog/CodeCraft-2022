package com.huawei.java.main;

import java.io.IOException;
import java.util.*;

public class Start2 {               //不设上限版
    public void run(String path,String out){
        Server[] servers1 = Server.init(path);
        Client[] clients1 = Client.init(path);
        Server[] servers = Server.getClientInfo(servers1, clients1, path);
        Client[] clients = Client.getServerInfo(servers1, clients1, path);

//        Server[] servers=Server.abandon(old_servers,1);     //线数只有1的边缘被禁用
//        for(int i=0;i<servers.length;i++){
//            servers[i].num=i;
//        }
//        List<Server> abandonS=new ArrayList<>();
//        k:for(Server s:old_servers){
//            for(Server ss:servers){
//                if(s==ss)
//                    continue k;
//            }
//            abandonS.add(s);
//        }
//        for(Client c:clients){
//            for(Server s:abandonS){
//                c.serverList.remove(s);
//            }
//        }
//        for(Client c:clients){
//            c.serverNum=c.serverList.size();
//        }

        int sacrificeMax = (int) (Client.times * 0.05);         //同一个边缘节点最大白嫖次数
        int[][] gragh = Server.getGragh(servers1, clients1, path);                    //存放每个客户的原始边缘节点列表
        int[] static_servernum = new int[clients.length];         //存放每个客户的原始线数
        for (int i = 0; i < clients.length; i++) {
            static_servernum[i] = clients[i].serverNum;
        }
        int[] static_clientnum = new int[servers.length];
        for (int i = 0; i < servers.length; i++) {
            static_clientnum[i] = servers[i].clientNum;
        }
        for (int i = 0; i < servers.length; i++) {
            for (int j = 0; j < Client.times; j++) {
                servers[i].time_rest.put(j, servers[i].band_width);  //初始化每个边缘的<时刻-余量>表
            }
        }
        SingleStrategy[][] output = new SingleStrategy[Client.times][clients.length];     //[时刻数][客户数] map<边缘id，流id>
        for (int i = 0; i < output.length; i++) {
            for (int j = 0; j < output[0].length; j++) {
                output[i][j] = new SingleStrategy();
            }
        }
        //-------------------------------------------开始5%部分----------------------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {         //test:边缘节点按照容量降序排序
            @Override
            public int compare(Server o1, Server o2) {
                return o2.band_width - o1.band_width;
            }
        });
        for(int i=0;i<servers.length;i++){      //对每一列
            if(servers[i].isDead){
                continue;
            }
            Map<Integer,Integer> t_b=new HashMap<>();
            for(int j=0;j<Client.times;j++){
                int sum=0;
                for(Client c:servers[i].clientList){
                    for(int singleStream:c.stream_demand.get(j).values()){
                        sum+=singleStream;
                    }
                }
                t_b.put(j,sum);
            }
            List<Map.Entry<Integer, Integer>> T_B = new ArrayList<>(t_b.entrySet());
            Collections.sort(T_B, new Comparator<Map.Entry<Integer, Integer>>() {       //将一列根据相连客户需求和降序排序
                @Override
                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                    return o2.getValue() - o1.getValue();
                }
            });
            for(int j=0;j<sacrificeMax;j++){            //对这一列的前5%行进行分配,时刻=T_B.get(j).getKey()
                servers[i].sacri_times.add(T_B.get(j).getKey());
                servers[i].sacrificeNum++;
                Collections.sort(servers[i].clientList, new Comparator<Client>() {      //对该边缘下面的客户进行线数升序排序
                    @Override
                    public int compare(Client o1, Client o2) {
                        return o1.serverNum - o2.serverNum;
                    }
                });
                List<Stream> liu=new ArrayList<>();         //存储i时刻中所有未满足的流
                for(Client c:servers[i].clientList){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(T_B.get(j).getKey()).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                //找server[i]连通的流中最大的流
                for(Stream stream:liu){
                    if(servers[i].time_rest.get(T_B.get(j).getKey())>=stream.need){
                        servers[i].time_rest.put(T_B.get(j).getKey(),servers[i].time_rest.get(T_B.get(j).getKey())-stream.need);
                        stream.parent.stream_demand.get(T_B.get(j).getKey()).put(stream.id,0);
                        output[T_B.get(j).getKey()][stream.parent.num].item.put(servers[i].id,output[T_B.get(j).getKey()][stream.parent.num].item.getOrDefault(servers[i].id,"")+","+stream.id);
                    }else if(servers[i].time_rest.get(T_B.get(j).getKey())<stream.need){
                        continue;
                    }
                }
            }
        }
        //--------------------------------------------------开始95%部分-----------------------------------------------------
        Arrays.sort(servers, new Comparator<Server>() {         //将servers排回原来顺序
            @Override
            public int compare(Server o1, Server o2) {
                return o1.num - o2.num;
            }
        });
        for(int i=0;i<Client.times;i++){        //-------------填掉每个边缘节点的V
            for(Server s:servers)
                s.vrest=Math.min(Server.base_cost,s.band_width);       //每时刻开始，边缘节点的上限设为v和带宽的较小值
            List<Server> aliveS=new ArrayList<>();
            for(int j=0;j<servers.length;j++){
                if(servers[j].sacri_times.contains(i)||servers[j].isDead){
                    continue;
                }else {
                    aliveS.add(servers[j]);
                }
            }
            Collections.sort(aliveS, new Comparator<Server>() {     //给活边缘节点按线数升序排序 (或者先比线数后比容量？)******
                @Override
                public int compare(Server o1, Server o2) {
                    return o1.clientNum-o2.clientNum;
                }
            });
            for(Server s:aliveS){
                List<Stream> liu=new ArrayList<>();
                for(Client c:s.clientList){
                    for(Map.Entry<String,Integer> entry:c.stream_demand.get(i).entrySet()){
                        if(entry.getValue()!=0){
                            liu.add(new Stream(c, entry.getKey(), entry.getValue()));
                        }
                    }
                }
                Collections.sort(liu, new Comparator<Stream>() {
                    @Override
                    public int compare(Stream o1, Stream o2) {
                        return o2.need-o1.need;
                    }
                });
                for(Stream stream:liu){
                    if(s.vrest<stream.need){
                        continue;
                    }else if(s.vrest>=stream.need){
                        s.vrest-=stream.need;
                        s.time_rest.put(i,s.time_rest.get(i)-stream.need);
                        stream.parent.stream_demand.get(i).put(stream.id,0);
                        output[i][stream.parent.num].item.put(s.id,output[i][stream.parent.num].item.getOrDefault(s.id,"")+","+stream.id);
                    }
                }
            }

            //开始检查客户下的流是否都已经为0,把未得到满足的流id存起来，统一处理

        }

        //----------------------------------------------------填完V之后-------------------------------------------------------
        for(int i=0;i<Client.times;i++) {
            List<Stream> streams = new ArrayList<>();
            for (Client c : clients) {
                for (Map.Entry<String, Integer> entry : c.stream_demand.get(i).entrySet()) {
                    if (entry.getValue() != 0) {
                        streams.add(new Stream(c, entry.getKey(), entry.getValue()));
                    }
                }
            }
            Collections.sort(streams, new Comparator<Stream>() {
                @Override
                public int compare(Stream o1, Stream o2) {
                    return o2.need - o1.need;
                }
            });

            l:for (Stream stream : streams) {
                //对相通的边缘节点进行优先级排序
                for (Server s : servers) {      //优先级=[2(边缘已用量-V)+该流大小]/bandwidth
                    s.priority = (2.0 * (s.band_width - s.time_rest.get(i) - Server.base_cost) + stream.need) / s.band_width;
                }
                for (Server s : servers) {
                    if (s.clientNum == 1)
                        s.priority = 1000;
                }

                Collections.sort(stream.parent.serverList, new Comparator<Server>() {
                    @Override
                    public int compare(Server o1, Server o2) {
//                    return (int) (o1.priority-o2.priority);
                        if (o1.priority < o2.priority)
                            return -1;
                        else if (o1.priority > o2.priority)
                            return 1;
                        else
                            return 0;
                    }
                });
                for (Server s : stream.parent.serverList) {         //开始找最优先的边缘，满足流
                    if (s.time_rest.get(i) < stream.need) {
                        continue;
                    } else if (s.time_rest.get(i) >= stream.need) {
                        int trans = stream.need;
                        s.time_rest.put(i, s.time_rest.get(i) - trans);
//                    s.upper_limit=s.band_width-s.time_rest.get(T);
                        stream.parent.stream_demand.get(i).put(stream.id, 0);
                        output[i][stream.parent.num].item.put(s.id, output[i][stream.parent.num].item.getOrDefault(s.id, "") + "," + stream.id);
                        continue l;
                    }
                }
            }
        }
        //--------------------------------其余时刻填上限并扩展



        for(int i=0;i<output.length;i++){
            for(int j=0;j<output[0].length;j++){
                System.out.print(clients[j].id+":");
                for(Map.Entry<String ,String> entry:output[i][j].item.entrySet()){
                    System.out.print("<"+entry.getKey()+entry.getValue()+">");
                }
                System.out.println();
            }
        }
        try {
            SingleStrategy.writeDataToFile(output, out, clients);
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
